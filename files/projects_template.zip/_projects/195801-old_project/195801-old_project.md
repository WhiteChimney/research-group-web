---
title: 比较久远的项目
status: inactive

description: |
    项目比较简短或久远，仅在“研究项目“板块出现，而不在首页出现

people:
  - faculty_hanzhengfu
  - faculty_chenwei

layout: project
link: "http://lqcc.ustc.edu.cn"
---
